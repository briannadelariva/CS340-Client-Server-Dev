from pymongo import MongoClient
from bson.objectid import ObjectId
from IPython.display import display

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, user, passwd, host, port, database, collection):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        
        USER = user
        PASS = passwd
        HOST = host
        PORT = port
        DB = database
        COL = collection


        #USER = 'aacuser' 
        #PASS = 'best_password_ever' 
        #HOST = 'nv-desktop-services.apporto.com'
        #PORT = 32197 
        #DB = 'AAC'
        #COL = 'animals'
        #
        # Initialize Connection
        #

        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

    def create(self, data):
        if data is not None:
            result = self.collection.insert_one(data)
            return result.inserted_id is not None
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    def read(self, query=None):
        try:
            if query is None:
                documents = self.collection.find()
            else:
                documents = self.collection.find(query)
            return list(documents)
        
        except Exception as e:
            print(f"Error during document retrieval: {e}")
            return []

    def update_one(self, filter_query=None, update_data=None):
        result = self.collection.update_one(filter_query, update_data)
        return result
        
    def delete_one(self, delete_filter_query=None):
        result = self.collection.delete_one(delete_filter_query)
        return result
    
    def display_documents(self, cursor):
        document_list = [doc for doc in cursor]
        document_string = str(document_list)
        display(document_string)

    
    
    
    
    
    
    
    
    
    
    
    
    

